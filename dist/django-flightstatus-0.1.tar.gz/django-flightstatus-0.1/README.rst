============
Flight status
=============

Flight status is a simple api call to FlightStat REST to retrieve a flight status.

Quick start
-----------

1. Add "flightstatus" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'flightstatus',
    ]
